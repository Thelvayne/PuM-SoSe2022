import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PlaygroundTest
{
    @Test
    static void testZeroSize(){

        assertEquals(new IndexOutOfBoundsException(),new Playground(0));
        assertEquals(new IndexOutOfBoundsException(),new Playground(-1));
    }

    static void testVeryLargeSize(){

    }

    public static void main(String[] args){

        Playground p = new Playground(10);

        /*
        Playground pp = new Playground(20);
        Playground ppp = new Playground(5);
        Playground pppp = new Playground(4);
        Playground ppppp = new Playground(3);
        Playground pppppp = new Playground(2);
          */

        //testZeroSize();
        System.out.println("-------------------------------------------");
        FindTheWay f = new FindTheWay(p.getPlayground());
    }

    @Test
    void testNegativeFieldSize()
    {
        int size = -1;
        Playground play = new Playground(size);
        assertEquals(null,play.getPlayground());
    
    }

    @Test
    void testSizeOne()
    {
        int size = 1;
        Playground play = new Playground(size);
        assertEquals(1, play.getPlayground().length);
    }

    @Test
    void testSizeZero()
    {
        int size = 0;
        Playground play = new Playground(size);
        assertEquals(1, play.getPlayground().length);
    }
    
}