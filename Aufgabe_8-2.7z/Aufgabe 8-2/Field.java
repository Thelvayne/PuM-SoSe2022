public enum Field {
    WALL,PATH,FREE;
    
}
