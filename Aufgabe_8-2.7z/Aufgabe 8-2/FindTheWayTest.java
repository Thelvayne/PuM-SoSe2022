import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FindTheWayTest {
    

    @Test
    void testFoundWayToEnd()
    {
        Field[][] p = {{Field.FREE, Field.FREE, Field.FREE, Field.FREE},
            {Field.WALL, Field.WALL, Field.FREE, Field.WALL},
            {Field.FREE, Field.FREE, Field.FREE, Field.FREE},
            {Field.FREE, Field.FREE, Field.FREE, Field.FREE}};
            FindTheWay f = new FindTheWay(p);

            assertEquals(Field.PATH, f.getSolvedField()[0][0]);
            assertEquals(Field.PATH, f.getSolvedField()[0][1]);
            assertEquals(Field.PATH, f.getSolvedField()[0][2]);
            assertEquals(Field.PATH, f.getSolvedField()[1][2]);
            assertEquals(Field.PATH, f.getSolvedField()[2][2]);
            assertEquals(Field.PATH, f.getSolvedField()[3][2]);
            assertEquals(Field.PATH, f.getSolvedField()[3][3]);
    }

    @Test
    void testFieldWithNoWayToLastLine()
    {
        Field[][] p = {{Field.FREE, Field.FREE, Field.FREE, Field.FREE, Field.FREE, Field.FREE, Field.FREE},
            {Field.WALL, Field.WALL, Field.FREE, Field.WALL, Field.WALL, Field.WALL, Field.WALL},
            {Field.FREE, Field.FREE, Field.FREE, Field.FREE, Field.FREE, Field.FREE, Field.FREE},
            {Field.FREE, Field.WALL, Field.WALL, Field.WALL, Field.WALL, Field.WALL, Field.WALL},
            {Field.FREE, Field.FREE, Field.FREE, Field.FREE, Field.FREE, Field.FREE, Field.FREE},
            {Field.WALL, Field.WALL, Field.WALL, Field.WALL, Field.WALL, Field.WALL, Field.WALL},
            {Field.FREE, Field.FREE, Field.FREE, Field.FREE, Field.FREE, Field.FREE, Field.FREE},};
            FindTheWay f = new FindTheWay(p);
        assertEquals(Field.PATH, f.getSolvedField()[4][6]);
    }
}