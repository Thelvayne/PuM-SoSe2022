package two;

public enum Field {
    WALL,PATH,FREE;
    
}
