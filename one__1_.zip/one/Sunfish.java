package one;

public class Sunfish extends Fish
{
    public Sunfish(String name) {
        super(name);
    }
}
