package one;

public class PetShelter
{
    public static void main(String[]args){

        Cat cat = new Cat("Mauz");
        Dog dog = new Dog("Ra");
        Lizard lizard = new Lizard("Lurch");
        Penguin penguin = new Penguin("Bro");
        Sunfish sunfish = new Sunfish("Moon");


        PetShelterTest test = new PetShelterTest();

        test.testSay();
        test.testMove();
        test.testPolymorph();

    }
}
